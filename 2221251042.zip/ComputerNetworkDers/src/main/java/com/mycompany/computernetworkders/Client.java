/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.computernetworkders;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author emirkaan.ogsarim@fsm.edu.tr
 * 2221251042
 */
public class Client {
    public static void main(String[] args) {
        String serverIP = "127.0.0.1"; // Sunucunun IP adresi (yerel bilgisayar için 127.0.0.1)
       int portToConnect = 5000; // Sunucunun dinlediği port

        try {
            Socket socket = new Socket(serverIP, portToConnect); 
            PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);

            out.println("09.03.2025 Pazar 15.30 Bu benim yazdığım ilk network kodu!"); 
            System.out.println("Sunucuya mesaj gönderildi.");

            socket.close(); // Bağlantıyı kapat
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
