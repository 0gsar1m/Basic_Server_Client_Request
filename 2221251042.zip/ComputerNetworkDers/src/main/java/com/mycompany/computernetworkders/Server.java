/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.computernetworkders;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author emirkaan.ogsarim@fsm.edu.tr
 * 2221251042
 */
public class Server {

     public static void main(String[] args) {
        int portListeningOn = 5000; // Sunucunun dinleyeceği port
        try {
            ServerSocket serverSocket = new ServerSocket(portListeningOn);
            System.out.println("Sunucu " + portListeningOn + " portunda başlatıldı...");

            while (true) { // Sonsuz döngüde istemcileri dinle
                Socket clientSocket = serverSocket.accept(); // İstemci bağlanana kadar bekle
                System.out.println("Bağlanan istemci: " + clientSocket.getInetAddress() + ":" + clientSocket.getPort());

                // Gelen mesajı oku
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                String message = in.readLine();
                System.out.println("İstemciden gelen mesaj: " + message);

                clientSocket.close(); // Bağlantıyı kapat
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
